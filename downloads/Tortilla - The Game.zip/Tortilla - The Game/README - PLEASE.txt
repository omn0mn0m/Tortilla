Tortilla - The Game v0.0.5
------------------------------------------------
Happy birthday, Tori! You are the dancing queen!
------------------------------------------------

Installation:
1) Download the compressed Tortilla - The Game folder.
2) Unzip it.
3) Done.

------------------------------------------------

How to Play:
For the actual story part, for now it is mostly an
interactive fiction rather than a game. Once you go
to sleep, the game will open up into a dungeon
crawler I had been working on for the last year or
so.

Commands for the story are self-explanatory. If you
need help during the dream mode (dungeon), just type
help.

-------------------------------------------------

Updating:
There are two options for updating:

1) Redownload the whole compressed folder and go through installation again.
2) Download the "update" compressed folder and paste into the installation.

-------------------------------------------------

Troubleshooting:

- Make sure that you have Java 7 installed.
- You need administrator permissions on your computer.